import { useState, useCallback, useEffect, useRef } from 'react';
import useGeolocation from './hooks/useGeolocation';
import { searchNearbyNightShops } from './utils/api';
import MapComponent from './components/MapComponent';
import Header from './components/Header';
import BottomSheet from './components/BottomSheet';
import LocationPermission from './components/LocationPermission';
import RecenterButton from './components/RecenterButton';

// Get API key from environment variable
const GOOGLE_MAPS_API_KEY = import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '';

function App() {
  const { position, error: geoError, isLoading: geoLoading, refresh: refreshLocation } = useGeolocation();
  const [shops, setShops] = useState([]);
  const [selectedShop, setSelectedShop] = useState(null);
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState(null);
  const mapRef = useRef(null);

  // Search for shops when position is available
  const searchShops = useCallback(async () => {
    if (!position || !mapRef.current) return;

    setIsSearching(true);
    setSearchError(null);

    try {
      const results = await searchNearbyNightShops(
        mapRef.current,
        { lat: position.lat, lng: position.lng },
        2000 // 2km radius
      );
      setShops(results);
      
      // Auto-select nearest open shop
      const nearestOpen = results.find(s => s.isOpen === true && !s.isFlagged);
      if (nearestOpen) {
        setSelectedShop(nearestOpen);
      }
    } catch (err) {
      console.error('Search error:', err);
      setSearchError(err.message);
    } finally {
      setIsSearching(false);
    }
  }, [position]);

  // Trigger search when map loads and position is available
  const handleMapLoad = useCallback((mapInstance) => {
    mapRef.current = mapInstance;
    if (position) {
      searchShops();
    }
  }, [position, searchShops]);

  // Search when position changes
  useEffect(() => {
    if (position && mapRef.current) {
      searchShops();
    }
  }, [position, searchShops]);

  // Handle shop selection
  const handleSelectShop = useCallback((shop) => {
    setSelectedShop(shop);
  }, []);

  // Handle shop flagging
  const handleFlagShop = useCallback((shopId, isFlagged) => {
    setShops(prevShops => 
      prevShops.map(shop => 
        shop.id === shopId ? { ...shop, isFlagged } : shop
      ).sort((a, b) => {
        // Re-sort: prioritize non-flagged open shops
        if (a.isOpen === true && !a.isFlagged && (b.isOpen !== true || b.isFlagged)) return -1;
        if (b.isOpen === true && !b.isFlagged && (a.isOpen !== true || a.isFlagged)) return 1;
        if (a.isFlagged && !b.isFlagged) return 1;
        if (!a.isFlagged && b.isFlagged) return -1;
        return a.distance - b.distance;
      })
    );
  }, []);

  // Handle refresh
  const handleRefresh = useCallback(() => {
    refreshLocation();
    if (mapRef.current) {
      searchShops();
    }
  }, [refreshLocation, searchShops]);

  // Handle recenter
  const handleRecenter = useCallback(() => {
    if (mapRef.current && position) {
      mapRef.current.panTo(position);
      mapRef.current.setZoom(15);
      setSelectedShop(null);
    }
  }, [position]);

  // Show location permission screen if no position
  if (!position || geoError) {
    return (
      <LocationPermission
        error={geoError}
        onRetry={refreshLocation}
        isLoading={geoLoading}
      />
    );
  }

  // Check for API key
  if (!GOOGLE_MAPS_API_KEY) {
    return (
      <div className="fixed inset-0 bg-night-900 flex flex-col items-center justify-center p-6">
        <div className="max-w-md text-center">
          <h1 className="font-display font-bold text-2xl text-neon-red mb-4">
            Configuration Required
          </h1>
          <p className="text-night-400 mb-6">
            Please add your Google Maps API key to the environment variables.
          </p>
          <code className="block p-4 bg-night-800 rounded-xl text-neon-green text-sm text-left">
            VITE_GOOGLE_MAPS_API_KEY=your_api_key_here
          </code>
          <p className="text-night-500 text-sm mt-4">
            Create a <code className="text-neon-yellow">.env</code> file in the project root with your API key.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full w-full relative overflow-hidden bg-night-900">
      {/* Header */}
      <Header 
        onRefresh={handleRefresh} 
        isLoading={isSearching || geoLoading}
        shopCount={shops.filter(s => s.isOpen === true && !s.isFlagged).length}
      />

      {/* Map */}
      <div className="absolute inset-0">
        <MapComponent
          userLocation={position}
          shops={shops}
          selectedShop={selectedShop}
          onSelectShop={handleSelectShop}
          onMapLoad={handleMapLoad}
          apiKey={GOOGLE_MAPS_API_KEY}
        />
      </div>

      {/* Recenter button */}
      <RecenterButton 
        onClick={handleRecenter}
        isVisible={!!selectedShop}
      />

      {/* Bottom sheet with shop list */}
      <BottomSheet
        shops={shops}
        selectedShop={selectedShop}
        onSelectShop={handleSelectShop}
        onFlagShop={handleFlagShop}
        isLoading={isSearching}
      />

      {/* Search error toast */}
      {searchError && (
        <div className="fixed top-24 left-4 right-4 z-50 animate-slide-up">
          <div className="bg-neon-red/10 border border-neon-red/30 rounded-xl p-4">
            <p className="text-neon-red text-sm text-center">{searchError}</p>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
