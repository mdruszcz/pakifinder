// Night Shop Finder - Google Places API Utilities
// Belgian-specific search terms for night shops

const SEARCH_KEYWORDS = [
  'night shop',
  'nachtwinkel',
  'alimentation',
  'alimentation générale',
  'épicerie de nuit',
  'tabac',
  'convenience store',
  'late night shop',
];

// Flagged shops storage (in production, use a backend)
const FLAGGED_SHOPS_KEY = 'nightshop_flagged';
const FLAG_DURATION = 2 * 60 * 60 * 1000; // 2 hours

/**
 * Get flagged shops from localStorage
 */
export const getFlaggedShops = () => {
  try {
    const stored = localStorage.getItem(FLAGGED_SHOPS_KEY);
    if (!stored) return {};
    
    const flagged = JSON.parse(stored);
    const now = Date.now();
    
    // Clean up expired flags
    const cleaned = Object.entries(flagged).reduce((acc, [id, timestamp]) => {
      if (now - timestamp < FLAG_DURATION) {
        acc[id] = timestamp;
      }
      return acc;
    }, {});
    
    localStorage.setItem(FLAGGED_SHOPS_KEY, JSON.stringify(cleaned));
    return cleaned;
  } catch {
    return {};
  }
};

/**
 * Flag a shop as potentially closed
 */
export const flagShop = (placeId) => {
  try {
    const flagged = getFlaggedShops();
    flagged[placeId] = Date.now();
    localStorage.setItem(FLAGGED_SHOPS_KEY, JSON.stringify(flagged));
    return true;
  } catch {
    return false;
  }
};

/**
 * Clear flag for a shop (if user reports it's actually open)
 */
export const clearShopFlag = (placeId) => {
  try {
    const flagged = getFlaggedShops();
    delete flagged[placeId];
    localStorage.setItem(FLAGGED_SHOPS_KEY, JSON.stringify(flagged));
    return true;
  } catch {
    return false;
  }
};

/**
 * Check if a shop is flagged
 */
export const isShopFlagged = (placeId) => {
  const flagged = getFlaggedShops();
  return !!flagged[placeId];
};

/**
 * Search for nearby night shops using Google Places API
 * @param {google.maps.Map} map - The Google Maps instance
 * @param {Object} location - { lat, lng }
 * @param {number} radius - Search radius in meters (default 2000m = 2km)
 */
export const searchNearbyNightShops = (map, location, radius = 2000) => {
  return new Promise((resolve, reject) => {
    if (!window.google || !window.google.maps) {
      reject(new Error('Google Maps not loaded'));
      return;
    }

    const service = new window.google.maps.places.PlacesService(map);
    const allResults = [];
    const seenIds = new Set();
    let completedSearches = 0;

    const processResults = (results, status) => {
      completedSearches++;
      
      if (status === window.google.maps.places.PlacesServiceStatus.OK && results) {
        results.forEach(place => {
          if (!seenIds.has(place.place_id)) {
            seenIds.add(place.place_id);
            allResults.push(place);
          }
        });
      }

      // When all searches complete, process and return results
      if (completedSearches === SEARCH_KEYWORDS.length) {
        // Filter and sort results
        const processedResults = allResults
          .map(place => ({
            id: place.place_id,
            name: place.name,
            address: place.vicinity,
            location: {
              lat: place.geometry.location.lat(),
              lng: place.geometry.location.lng(),
            },
            isOpen: place.opening_hours?.isOpen?.() ?? null,
            rating: place.rating,
            totalRatings: place.user_ratings_total,
            photos: place.photos,
            isFlagged: isShopFlagged(place.place_id),
            distance: calculateDistance(
              location.lat,
              location.lng,
              place.geometry.location.lat(),
              place.geometry.location.lng()
            ),
          }))
          .filter(place => place.isOpen !== false) // Remove definitively closed
          .sort((a, b) => {
            // Prioritize confirmed open, then by distance
            if (a.isOpen === true && b.isOpen !== true) return -1;
            if (b.isOpen === true && a.isOpen !== true) return 1;
            if (a.isFlagged && !b.isFlagged) return 1;
            if (!a.isFlagged && b.isFlagged) return -1;
            return a.distance - b.distance;
          });

        resolve(processedResults);
      }
    };

    // Search for each keyword
    SEARCH_KEYWORDS.forEach(keyword => {
      const request = {
        location: new window.google.maps.LatLng(location.lat, location.lng),
        radius: radius,
        keyword: keyword,
        type: 'store',
      };

      service.nearbySearch(request, processResults);
    });
  });
};

/**
 * Get detailed place information
 */
export const getPlaceDetails = (map, placeId) => {
  return new Promise((resolve, reject) => {
    if (!window.google || !window.google.maps) {
      reject(new Error('Google Maps not loaded'));
      return;
    }

    const service = new window.google.maps.places.PlacesService(map);
    
    service.getDetails(
      {
        placeId: placeId,
        fields: [
          'name',
          'formatted_address',
          'formatted_phone_number',
          'opening_hours',
          'geometry',
          'photos',
          'rating',
          'user_ratings_total',
          'url',
        ],
      },
      (place, status) => {
        if (status === window.google.maps.places.PlacesServiceStatus.OK) {
          resolve({
            id: placeId,
            name: place.name,
            address: place.formatted_address,
            phone: place.formatted_phone_number,
            location: {
              lat: place.geometry.location.lat(),
              lng: place.geometry.location.lng(),
            },
            isOpen: place.opening_hours?.isOpen?.() ?? null,
            hours: place.opening_hours?.weekday_text,
            rating: place.rating,
            totalRatings: place.user_ratings_total,
            photos: place.photos,
            googleMapsUrl: place.url,
            isFlagged: isShopFlagged(placeId),
          });
        } else {
          reject(new Error('Failed to get place details'));
        }
      }
    );
  });
};

/**
 * Calculate distance between two points using Haversine formula
 * @returns distance in meters
 */
export const calculateDistance = (lat1, lng1, lat2, lng2) => {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = (lat1 * Math.PI) / 180;
  const φ2 = (lat2 * Math.PI) / 180;
  const Δφ = ((lat2 - lat1) * Math.PI) / 180;
  const Δλ = ((lng2 - lng1) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c;
};

/**
 * Format distance for display
 */
export const formatDistance = (meters) => {
  if (meters < 1000) {
    return `${Math.round(meters)}m`;
  }
  return `${(meters / 1000).toFixed(1)}km`;
};

/**
 * Generate navigation URL
 */
export const getNavigationUrl = (destination, preferWaze = false) => {
  const { lat, lng } = destination;
  
  if (preferWaze) {
    return `https://waze.com/ul?ll=${lat},${lng}&navigate=yes`;
  }
  
  // Google Maps URL that works on both mobile and desktop
  return `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}&travelmode=walking`;
};

/**
 * Check if device is iOS
 */
export const isIOS = () => {
  return /iPad|iPhone|iPod/.test(navigator.userAgent);
};

/**
 * Check if device is Android
 */
export const isAndroid = () => {
  return /Android/.test(navigator.userAgent);
};

/**
 * Get current time formatted
 */
export const getCurrentTime = () => {
  return new Date().toLocaleTimeString('en-BE', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
};
